library(shinydashboard)


################## Main UI ###########################
header <- dashboardHeader(
  title = "Educational Attainment Levels in the US",
  titleWidth = 450
)

sidebar <- dashboardSidebar(
  sidebarMenuOutput("menu"),
  collapsed = T
)

homeTab <- tabItem(
  tabName = "home",
  uiOutput("homeUI")
)

mapTab <- tabItem(
  tabName = "mapView",
  uiOutput("mapUI")
)

barTab <- tabItem(
  tabName = "barChart",
  uiOutput("barChartUI")
)

anovaTab <- tabItem(
  tabName = "blockAnova",
  uiOutput("blockAnovaUI")
)

body <- dashboardBody(
  
  tabItems(
    homeTab,
    mapTab,
    barTab,
    anovaTab
  )
  

)



dashboardPage(header,sidebar,body)




