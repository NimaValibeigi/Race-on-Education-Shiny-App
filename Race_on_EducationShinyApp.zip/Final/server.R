library(leaflet)
library(tidyverse)
library(plotly)
library(glue)
library(grDevices)


states <- geojsonio::geojson_read("https://rstudio.github.io/leaflet/json/us-states.geojson",
                                  what = "sp")

df <- read.csv("663finaldata.csv",stringsAsFactors = F)


high_df <- df %>% filter(education == "higher education") %>% na.omit(percentage)
low_df <- df %>% filter(education == "lower education") %>% na.omit(percentage)
# constants
high_map_min <- min(high_df$percentage)-.01
high_map_max <- max(high_df$percentage)+.01

low_map_min <- min(low_df$percentage)-.01
low_map_max <- max(low_df$percentage)+.01

v <- reactiveValues()


# State options

state_names <- c(
  "United States" = "UnitedStates",
  "Alabama" = "Alabama",
  'Alaska' = 'Alaska' ,
  "Arizona" = "Arizona",
  "Arkansas" = "Arkansas",
  "California" = "California",
  "Colorado" = "Colorado",
  "Connecticut" = "Connecticut",
  "Delaware" = "Delaware",
  "District of Columbia (DC)" = "DistrictofColumbia",
  "Florida" = "Florida",
  "Georgia" = "Georgia",
  "Idaho" = "Idaho",
  "Illinois" = "Illinois",
  "Indiana" = "Indiana",
  "Iowa" = "Iowa",
  "Kansas" = "Kansas",
  "Kentucky" = "Kentucky" ,
  "Louisiana" = "Louisiana",
  "Maine" = "Maine",
  "Maryland" = "Maryland",
  "Massachusetts" = "Massachusetts",
  "Michigan" = "Michigan",
  "Minnesota" = "Minnesota",
  "Mississippi" = "Mississippi",
  "Missouri" = "Missouri",
  "Montana" = "Montana",
  "Nebraska" = "Nebraska",
  "Nevada" = "Nevada",
  "New Hampshire" = "NewHampshire",
  "New Jersey" = "NewJersey",
  "New Mexico" = "NewMexico",
  "New York" = "NewYork",
  "North Carolina" = "NorthCarolina",
  "North Dakota" = "NorthDakota",
  "Ohio" = "Ohio",
  "Oklahoma" = "Oklahoma",
  "Oregon" = "Oregon",
  "Pennsylvania" = "Pennsylvania",
  "Rhode Island" = "RhodeIsland",
  "South Carolina" = "SouthCarolina",
  "South Dakota" = "SouthDakota",
  "Tennessee" = "Tennessee",
  "Texas" = "Texas",
  "Utah" = "Utah",
  "Vermont" = "Vermont",
  "Virginia" = "Virginia",
  "Washington" = "Washington",
  "West Virginia" = "WestVirginia",
  "Wisconsin" = "Wisconsin",
  "Wyoming" = "Wyoming"
)



# server
shinyServer(function(input,output,server){
  
  
  output$menu <- renderMenu({
    menu_list <- list(
      menuItem("Home", tabName = "home",
               icon = icon("house")),
      menuItem("Map View", tabName = "mapView",
               icon = icon("map-location-dot")),
      menuItem("Bar Chart", tabName = "barChart",
               icon = icon("chart-column")),
      menuItem("Block Anova",tabName = "blockAnova",
               icon = icon("calculator"))
    )
    
    sidebarMenu(id = "tabs",
                .list = menu_list,
                width = 175)
    
  })
  
  
############################ HOME OUTPUTS ###########################################################
  
  output$homeUI <- renderUI({
    fluidPage(
      div(
      h1("School Achievement Levels in the United States"),
      h2("STAT 663 Final"),
      h2("John Carroll and Nima Valibeigi"),
      hr(),
      hr(),
      h2("We analyzed the given data (Rates of high school completion and bachelor's degree attainment among persons age 25 and over, by race/ethnicity and state: 2019).... To help us draw inferences to answer the following question: 
Is there a significant effect between race and/or education level (high school vs. bachelors) and/or State on the percentage of education completion?"),
      hr(),
      h2("It is believed that race and ethnicity continue to be major factors influencing children's and adults' experiences of education at all levels and in a variety of respects."),
      hr(),
      h2("This is an important question to explore because it elucidates the relationship between race and education by region. This information will bring more awareness to this idea and hopefully result in the legislation of necessary policy."),
      style = "text-align: center; vertical-align: middle"
    ))
    
  })
  

  ########################## MAP OUTPUTS ##############################################################
  
   
  output$mapUI <- renderUI({
    fluidRow(
      column(3,
             wellPanel(
               id = "control",
               top = 75,
               left = 75,
               width = 225,
               fixed = TRUE,
               draggable = TRUE,
               height = 170,
               style = "opacity: 0.8",
               selectInput(
                 "mapRaceChoice",
                 "Demographic",
                 selected = "total",
                 choices = list(
                   "Total" = "total",
                   "White" = "white",
                   "Black" = "black",
                   "Hispanic" = "hispanic",
                   "Asian" = "asian",
                   "Two or More" = "twoormore"
                 )
               ),
               selectInput(
                 "mapEducationLevel",
                 "Education Level",
                 selected = "higher education",
                 choices = list(
                   "College or Higher" = "higher education",
                   "High School or Higher" = "lower education"
                 )
               )
             )# end of sliderInput1
      ),
      column(9,
             leafletOutput("map", width = "100%",height = "1200px"),
             absolutePanel(
               class = "panel panel-default",
               top = 75,
               left = 75,
               width = 100,
               height = 50,
               style = "opacity: 0.8",
               align = "center",
               textOutput("mapAverageMsg")
             ))
    )
  })
  
  
  output$mapAverageMsg <- renderText({
    req(v$map_data)
    avg <- v$map_data %>% filter(State == "UnitedStates") %>% select(percentage) %>% unlist()
    glue("National Average: {avg}%")
  })
  
  output$map <- renderLeaflet({
    v$map_data <- df %>% filter(race == input$mapRaceChoice,
                              education == input$mapEducationLevel)
    
    states@data <-
      left_join(
        states@data,
        v$map_data,
        by = c("name" = "State")
      )
    
    if(input$mapEducationLevel == "higher education"){
      bins <- seq(high_map_min,high_map_max,by = (high_map_max-high_map_min)/9)
    }
    else{
      bins <- seq(low_map_min,low_map_max,by = (low_map_max-low_map_min)/9)
    }
    
    pal <- colorBin("BuPu", domain = v$map_data$percentage, bins = bins)
    
    
    m <- leaflet(states) %>%
      setView(-102, 37.8, zoom = 4.5) %>%
      addTiles()
    
    m <- m %>% addPolygons(
      fillColor = ~ pal(percentage),
      weight = 2,
      opacity = 1,
      color = "white",
      dashArray = "3",
      fillOpacity = 0.7
    ) %>%
      addLegend(
        pal = pal,
        values = ~ percentage,
        opacity = 0.7,
        title = NULL,
        position = "bottomright"
      )
    
    m
  })
  

  ############################# BAR CHART OUTPUTS #####################################################
  
  output$barChartUI <- renderUI({
    fluidPage(
      titlePanel("Display Bar Charts"),
      sidebarLayout(position = "left",
                    sidebarPanel(
                      checkboxGroupInput("barStateChoice",
                                         "Choose States to Include",
                                         choices = state_names,
                                         selected = c("Arizona","California","Connecticut","Georgia","Minnesota","UnitedStates","Virginia")),
                      width = 2
                    ),
                    mainPanel(
                      fluidRow(
                      box(
                        height = 200,
                        width = 250,
                        align = "center",
                        column(
                          2,
                          checkboxGroupInput(
                            "barRaceChoice",
                            "Demographic",
                            selected = list("total",
                                            "white",
                                            "black",
                                            "hispanic",
                                            "asian",
                                            "twoormore"),
                            choices = list(
                              "Total" = "total",
                              "White" = "white",
                              "Black" = "black",
                              "Hispanic" = "hispanic",
                              "Asian" = "asian",
                              "Two or More" = "twoormore"
                            )
                          )
                          ),
                        column(
                          2,
                          selectInput(
                            "barEducationLevel",
                            "Education Level",
                            selected = "higher education",
                            choices = list(
                              "College or Higher" = "higher education",
                              "High School or Higher" = "lower education"
                            )
                          )),
                        column(
                          2,
                          actionButton("drawBarChart","Draw Chart")
                        )
                      )
                    ),
                    fluidRow(
                      plotlyOutput("barChartPlotly")
                    ))
      )
    )
    
  
  })
  
  
  output$barChartPlotly <- renderPlotly({
   x <- input$drawBarChart
   chart_df <- df %>%
     filter(State %in% isolate(input$barStateChoice),
            race %in% isolate(input$barRaceChoice),
            education == isolate(input$barEducationLevel))
    
   
   fig <- ggplot(data = chart_df, aes(x = State, y = percentage, fill = race)) +
     geom_bar(position = "dodge", stat = "identity") +
     geom_errorbar(aes(ymin=percentage-se, ymax=percentage+se), width=.2,
                   position=position_dodge(.9)) +
     theme(axis.text = element_text(size = 16))
   
   ggplotly(fig)
    
     
  })
  
  
  
  ############################ BLOCK ANOVA OUTPUTS ####################################################
  
  anova_vars <- reactiveValues(tukey = NA,
                               summary = "")
  
  output$blockAnovaUI <- renderUI({
    
    
    fluidPage(
      titlePanel("Conduct Block Anova Testing"),
      sidebarLayout(position = "left",
                    sidebarPanel(
                      checkboxGroupInput("anovaStateChoice",
                                         "Choose States to Include",
                                         choices = state_names,
                                         selected = state_names),
                      width = 2
                    ),
                    mainPanel(
                      fluidRow(
                        box(
                          height = 200,
                          width = 250,
                          align = "center",
                          column(
                            2,
                            checkboxGroupInput(
                              "anovaRaceChoice",
                              "Demographic",
                              selected = list(
                                "White" = "white",
                                "Black" = "black",
                                "Hispanic" = "hispanic",
                                "Asian" = "asian",
                                "Two or More" = "twoormore"
                              ),
                              choices = list(
                                "White" = "white",
                                "Black" = "black",
                                "Hispanic" = "hispanic",
                                "Asian" = "asian",
                                "Two or More" = "twoormore"
                              )
                            )
                          ),
                          column(
                            2,
                            selectInput(
                              "anovaEducationLevel",
                              "Response Variables",
                              selected = "higher education",
                              choices = list(
                                "College or Higher" = "higher education",
                                "High School or Higher" = "lower education"
                              )
                            )),
                          column(
                            2,
                            actionButton("doAnova","Conduct Anova")
                          )
                        )
                      ),
                      fluidRow(
                        verbatimTextOutput("anovaSummary"),
                        DT::dataTableOutput("anovaTable")
                      ))
      )
    )
    })
  
  
  observeEvent(input$doAnova,{
    anovaDat <- df %>% filter(race %in% input$anovaRaceChoice,
                              State %in% input$anovaStateChoice,
                              education == input$anovaEducationLevel)
    
    ans <- aov(percentage~factor(race)+factor(State),data = anovaDat)
    anova_vars$summary <- anova(ans)
    anova_vars$tukey <- TukeyHSD(ans,"factor(race)",conf.level=.95)
    
  })
  
  
  output$anovaSummary <- renderPrint({
    req(anova_vars$summary)
    print(anova_vars$summary)
  })
  
  output$anovaTable <- DT::renderDataTable({
    req(anova_vars$tukey)
    dat <- anova_vars$tukey$'factor(race)'
    dframe <- data.frame(dat) %>%
      mutate(stat_sig = p.adj < .05) %>%
      rename(Difference = diff,
             `Upper Bound` = upr,
             `Lower Bound` = lwr,
             `Adjusted P-value` = p.adj)
    
    DT::datatable(dframe,
                  caption = htmltools::tags$caption(
                    style = 'text-align: center; font-size: 20px; font-weight: bold',
                    "Tukey's HSD Results"),
                  options=list(columnDefs = list(list(visible=FALSE, 
                                                      targets="stat_sig")))) %>%
      DT::formatRound(columns = c("Difference","Upper Bound", "Lower Bound", "Adjusted P-value"), digits = 2) %>%
      DT::formatStyle("stat_sig", 
                      target = "row", 
                      backgroundColor = DT::styleEqual(c(T),
                                                       rgb(0, 255, 0, alpha = 80,maxColorValue = 255)))
  })
  
})